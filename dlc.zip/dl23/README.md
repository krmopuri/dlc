# About
This website hosts the Deep Learning (AI5100/AI2100) course offered by [Dr. Konda Reddy Mopuri](https://krmopuri.github.io), at the department of Artificial Intelligence, [IIT Hyderabad](https://iith.ac.in/) during Jan-May 2023.

# Acknowledgement 
This template is forked from [kazemnejad/jekyll-course-website-template](https://github.com/kazemnejad/jekyll-course-website-template).
