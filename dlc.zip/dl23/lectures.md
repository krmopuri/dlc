---
layout: lectures
title: Lectures
permalink: /lectures/
---
You can download the lectures here. We will try to upload lectures prior to their corresponding classes.