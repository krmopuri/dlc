---
type: lecture
date: 2023-01-09
title: (dl-3) MLP - Representational Power of Networks of Neurons

# optional
# please use /static_files/notes directory to store notes
# thumbnail: /static_files/path/to/image.jpg

# optional
tldr: "Multi Layered Network of Neurons can learn any artbirary function!"
  
# optional
# set it to true if you dont want this lecture to appear in the updates section
hide_from_announcments: false

# optional
links: 
    #- url: /static_files/presentations/lec.zip
    #  name: notes
    #- url: https://colab.research.google.com/drive/1TNavc9-jzJXc1N05l06KYfgaSmu7zqxN?usp=sharing
    #  name: codes
    - url: /static_files/presentations/dl-3.pdf
      name: slides
    #- url: /static_files/presentations/lec.zip
    #  name: other
---

**Suggested Readings:**

- [Approximation by Superposition of Sigmoid Functions](https://web.njit.edu/~usman/courses/cs675_fall18/10.1.1.441.7873.pdf) 
- [Chapter 4 of Michael Nielson's book](http://neuralnetworksanddeeplearning.com/chap4.html)
