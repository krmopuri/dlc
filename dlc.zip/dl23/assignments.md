---
layout: assignments
title: Assignments
permalink: /assignments/
---
Assignments are posted (and solutions are handed-over) in the Google classroom.
