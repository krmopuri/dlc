<!--- The following template files from '_events' have been deleted.-->
sample_due.md
---
type: due
date: 2019-12-28T23:59:59+3:30
description: 'Custom Due/Deadline'
hide_from_announcments: true
---
sample_exam_due.md
---
type: exam
date: 2018-12-02T8:0:0+3:30
description: 'Midterm'
hide_from_announcments: true
---
**Topics:**
1. Topic 1
2. Topic 2
3. Topic 3
sample_raw_event.md
---
type: raw_event
date: 2019-01-26T08:00:00+3:30
name: Session
description: 'Sample Raw Event'
hide_from_announcments: true
---
<!--- The following template file from '_lectures' have been deleted.-->
---
type: lecture
date: 2018-09-16T8:00:00+4:30
title: Sample Lecture
tldr: "Short text to discribe what this lecture is about."
thumbnail: /static_files/presentations/lec.jpg
links: 
    - url: /static_files/presentations/lec.zip
      name: notes
    - url: /static_files/presentations/code.zip
      name: codes
    - url: https://google.com
      name: slides
---
**Suggested Readings:**
- [Readings 1](http://example.com)
- [Readings 2](http://example.com)
